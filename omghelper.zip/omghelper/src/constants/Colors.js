export const QUALITIES_COLORS = {
  common: '#FFFFFF',
  tc10: '#A1A1A1',
  hiem: '#FFA500',
  hot: '#FF4500',
  do: '#FF4B2B',
  kim: '#FFD700',
  am_kim: '#FF8C00',
  tu_kim: '#E066FF',
  thai_kim: '#00F2FF',
  ban_kim: '#ccd7cd',
  luu_kim: '#ffef6b',
};